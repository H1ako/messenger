import { default as URLScheme } from './url_scheme';
export declare var ws: URLScheme;
export declare var http: URLScheme;
export declare var sockjs: URLScheme;
