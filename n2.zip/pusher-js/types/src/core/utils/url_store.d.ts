declare const _default: {
    buildLogSuffix: (key: string) => string;
};
export default _default;
