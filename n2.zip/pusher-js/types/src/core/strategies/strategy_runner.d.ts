interface StrategyRunner {
    forceMinPriority: (number: any) => void;
    abort: () => void;
}
export default StrategyRunner;
