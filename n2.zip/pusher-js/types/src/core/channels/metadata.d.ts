interface Metadata {
    user_id?: string;
}
export default Metadata;
