import HTTPFactory from 'core/http/http_factory';
declare var HTTP: HTTPFactory;
export default HTTP;
