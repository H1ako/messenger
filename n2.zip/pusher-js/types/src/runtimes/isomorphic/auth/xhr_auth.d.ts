import { AuthTransport } from 'core/auth/auth_transports';
declare var ajax: AuthTransport;
export default ajax;
