declare const _default: {
    secretbox: {};
    randomBytes: {};
};
export default _default;
