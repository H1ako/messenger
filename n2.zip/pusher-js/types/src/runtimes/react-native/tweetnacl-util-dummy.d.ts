declare const _default: {
    encodeUTF8: {};
    decodeUTF8: {};
    encodeBase64: {};
    decodeBase64: {};
};
export default _default;
