// This is a wrapper to make importing the encrypted channel capable web build
// nicer
// import Pusher from 'pusher-js/with-encryption'
module.exports = require('../dist/web/pusher-with-encryption');
