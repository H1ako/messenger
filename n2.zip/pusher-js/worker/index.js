module.exports = require('../dist/worker/pusher.worker.js');
