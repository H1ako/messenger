"use strict";
require("./warnAboutDeprecatedCJSRequire")("Router");
module.exports = require("./index.js").Router;
