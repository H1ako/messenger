"use strict";
require("./warnAboutDeprecatedCJSRequire")("Switch");
module.exports = require("./index.js").Switch;
