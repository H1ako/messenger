var convert = require('./convert'),
    func = convert('defer', require('../defer'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
