var convert = require('./convert'),
    func = convert('clamp', require('../clamp'));

func.placeholder = require('./placeholder');
module.exports = func;
