module.exports = require('./overEvery');
