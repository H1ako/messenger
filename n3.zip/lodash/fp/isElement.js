var convert = require('./convert'),
    func = convert('isElement', require('../isElement'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
