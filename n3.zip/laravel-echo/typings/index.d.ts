declare let Pusher: any;
declare let io: any;
declare let Vue: any;
declare let axios: any;
declare let jQuery: any;
