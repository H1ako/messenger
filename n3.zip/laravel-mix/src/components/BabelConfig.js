class BabelConfig {
    /**
     *
     * @param {BabelConfig} config
     */
    register(config) {
        Config.babelConfig = config;
    }
}

module.exports = BabelConfig;
